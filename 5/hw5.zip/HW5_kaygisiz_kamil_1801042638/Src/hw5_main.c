/*
** main.c:
**
** The test/driver program for the homework.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/


#include <stdio.h>
#include "hw5_lib.h"


void test_operate_polynomials () 
{/*I don't have time to get random order, I wrote the pdf according to the first version*/
char ch,op;
double a;
double a0,a1,a2,a3,b0,b1,b2,b3;
	printf("Please enter input as (degree,coefficient) \nfor first polynomial(coeff should entered (3,a3) to (0,a0):\n");
	scanf("(%lf,%lf),(%lf,%lf),(%lf,%lf),(%lf,%lf)",&a,&a3,&a,&a2,&a,&a1,&a,&a0);
	ch=getchar();/*to get white spaces*/
	printf("Please enter an operator(only + , - ,*):\n");
	scanf("%c",&op);
	ch=getchar();/*to get white spaces*/
	printf("Please enter input as (degree, coefficient) \nfor second polynomial(coeff should entered (3,b3) to (0,b0):\n");
	scanf("(%lf,%lf),(%lf,%lf),(%lf,%lf),(%lf,%lf)",&a,&b3,&a,&b2,&a,&b1,&a,&b0);
	ch=getchar();
	operate_polynomials(&a3,&a2,&a1,&a0,&b3,&b2,&b1,&b0,op);
	/*After the operation, the coefficients change and I print*/
	if(op=='+')
		printf("%f,%f,%f,%f",a3,a2,a1,a0);
	if(op=='-')
		printf("%f,%f,%f,%f",a3,a2,a1,a0);
	if(op=='*')
		printf("%f,%f,%f,%f,%f,%f,%f",a3,a2,a1,a0,b3,b2,b1);
	
}


void test_four_d_vectors ()
{
	double mean_a0=0.0, mean_a1=0.0, mean_a2=0.0, mean_a3=0.0, longest_distance=0.0;
	int N=7;
	four_d_vectors (&mean_a0, &mean_a1, &mean_a2, &mean_a3, &longest_distance, N);
	printf("Mean a0: %f\nMean a1: %f\nMean a2: %f\nMean a3: %f\nThe longest distance between two points: %f\n\n\n", mean_a0, mean_a1, mean_a2, mean_a3, longest_distance);
}


void test_dhondt_method ()
{
	int partyA=10, partyB=800, partyC=300, partyD=200, partyE=100, numberOfSeats=55;
	dhondt_method (&partyA, &partyB, &partyC, &partyD, &partyE, numberOfSeats);
	printf("Party A: %d seat(s).\nParty B: %d seat(s).\nParty C: %d seat(s).\nParty D: %d seat(s).\nParty E: %d seat(s).\n\n\n", partyA, partyB, partyC, partyD, partyE);
}


void test_order_2d_points_cc ()
{
	double x1=3.0, y1=5.0, x2=3.0, y2=6.0, x3=0.0, y3=9.0;
	order_2d_points_cc (&x1, &y1, &x2, &y2, &x3, &y3);
	printf("Counter-Clockwise Order: (%f,%f) - (%f,%f) - (%f,%f)\n\n\n", x1, y1, x2, y2, x3, y3);
}


void test_number_encrypt ()
{
	unsigned char number=125;
	number_encrypt (&number);
	printf("Encrypted number: %d\n\n\n", number);
}


/*
** main function for testing the functions...
**
*/
int main(void) {
	test_operate_polynomials ();
	test_four_d_vectors ();
	test_dhondt_method ();
	test_order_2d_points_cc ();
	test_number_encrypt ();
	return (0);
} /* end main */
