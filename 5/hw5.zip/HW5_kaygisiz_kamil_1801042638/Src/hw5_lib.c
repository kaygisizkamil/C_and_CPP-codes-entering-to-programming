/*
** hw5_lib.c:
**
** The source file implementing library functions.
**
** Author: Yakup Genc. (c) 2018-2021
**
** Revision: 2021.04.02.23.55
** 
*/
#include<math.h>
#include <stdio.h>
#include "hw5_lib.h"

int find_max(int a,int b,int c,int d,int e){/*i used my own function same as hw3 to use in dhond method*/
	int maximum;

	maximum=a*(a >= b) * (a >= c)* (a >= d)*(a>=e)+/*if  the conditions  are satisfied  e.g first line(a>=b)*..) it will return 1 / true
										if first line satisfied a is greatest, it will return a*1*1*1 if not it'll control other lines*/
	 		b*(b > a) * (b >= c)* (b >= d)*(b>=e)+/* i did it like this (b>a) if i did (b>=a) would return a + b if a and b were equal*/
			c*(c > a) * (c > b) * (c >= d)*(c>=e)+ /*if i did c>=a and were c>=b in case of c=b or c= a the return value would be different*/
			d*(d > a) * (d > b) * (d > c) *(d>=e)+/*and so on*/
			e*(e > a) * (e > b) * (e > c) *(e > d);
			
			return maximum;
}
void operate_polynomials  (double* a3, double* a2, double* a1, double* a0, double* b3, double* b2, double* b1, double* b0, char op)
{
	double coef6,coef5,coef4,coef3,coef2,coef1,coef0;
	/*suppose user'll enter first polynomial degree and coef(3,a3) and after second polynomial degree and coef(2,a2) 
	i assigned the result coef to first
	  a3x^3,a0x^0 polynomial a3..a0*/
	/*coefficients assigned to *a3,2,1 when op=='+' , printing is done on main like the other function */
		if(op=='+'){/*just returning value is expected in pdf that is why nothing will be printed in this section*/
			*a3=*a3+(*b3);/*Assignment was made by summing, the contents of the address held by the pointer with the other *a3=coef of^3*/
			*a2=*a2+(*b2);
			*a1=*a1+(*b1);
			*a0=*a0+(*b0);/*coff^0*/
			
		}
		/*coefficients assigned to a when op=='-'*/
		else if(op=='-'){/*Assignment was made by subtraction, the contents of the address held by the pointer with the other*/
			*a3=*a3-(*b3);/*a3=coef of^3*/
			*a2=*a2-(*b2);/*a2=coef of^2*/
			*a1=*a1-(*b1);/*a1=coef of^1*/
			*a0=*a0+(*b0);/* *a0=coef of^0*/
		}
		/*coefficients assigned to starting from a3 to b1 when op=='*' */
		else if(op=='*'){
			 coef6=(*a3)*(*b3);/*coeff6 represent coeff^6*/
			 coef5=(*a3)*(*b2)+(*a2)*(*b3);
			 coef4=(*a3)*(*b1)+(*a2)*(*b2)+(*a1)*(*b3);
			 coef3=(*a3)*(*b0)+(*a2)*(*b1)+(*a1)*(*b2)+(*a0)*(*b3);
			 coef2=(*a2)*(*b0)+(*a1)*(*b1)+(*a0)*(*b2);
			 coef1=(*a1)*(*b0)+(*a0)*(*b1);
			 coef0=(*a0)*(*b0);/*coeff0 represent coeff^0*/
			 *a3=coef6; /*^6*/
			 *a2=coef5; /*^5*/
			 *a1=coef4; /*^4*/
			 *a0=coef3; /*^3*/
			 *b3=coef2; /*^2*/
			 *b2=coef1; /*^1*/
			 *b1=coef0; /*^0*/
			 *b0=0;/*to prevent confusion make b0 (0) and it represent nothing (it is not holding any adress of coef  at the end of 
			 multiplication)*/
		}
		else 
			printf("invalid opearation");


}








void four_d_vectors (double* mean_a0, double* mean_a1, double* mean_a2, double* mean_a3, double* longest_distance, int N)
{
	double d0, d1, d2, d3, euclidian_distance;
	int i;
	char ch;
	double temp0,temp1,temp2,temp3;
	double max,max_ctrl;
	float counter=1;
	printf("\nplease enter N 4D vectors of 4 double numbers:\n");
	scanf("%lf %lf %lf %lf",&d0,&d1,&d2,&d3);/*take the first vector*/
	ch=getchar();
	*mean_a0=d0;/*I assigned the initial vector values*/
	*mean_a1=d1;
	*mean_a2=d2;
	*mean_a3=d3;

	
	for(i=1;i<N;i++){
		counter++;/*to count how many vector entered*/
		if(d0==-1  && d1==-1  && d2==-1 && d3==-1) /*loop breaker*/
			break;
			
			temp0=d0;
			temp1=d1;
			temp2=d2;
			temp3=d3;
			scanf("%lf %lf %lf %lf",&d0,&d1,&d2,&d3);/*take other vector than first, up to n*/
			ch=getchar();
			
			*mean_a0=(*mean_a0+d0);/*first  assign the sum of values ​​i will divide it by the number of counters outside the loop*/
			*mean_a1=(*mean_a1+d1);
			*mean_a2=(*mean_a2+d2);
			*mean_a3=(*mean_a3+d3);

			temp0=d0-temp0;/*For euclidian_distance I assigned the differences to temp.*/
			temp1=d1-temp1;
			temp2=d2-temp2;
			temp3=d3-temp3;
			
			distance_between_4d_points(temp0,temp1,temp2,temp3,&euclidian_distance);/* get the euclidian_distance*/
			max=euclidian_distance;/*assign it to max to control*/
			if(i==1){
				max_ctrl=max;
			}
			
			if(max_ctrl>max)
				*longest_distance=max_ctrl;
			else
				*longest_distance=max;
			/*the top if else statement are used to record the largest euclidian distance*/
			
	}
			*mean_a0/=counter;/*i pulled the averages*/
			*mean_a1/=counter;
			*mean_a2/=counter;
			*mean_a3/=counter;
	
}


void distance_between_4d_points (double d0, double d1, double d2, double d3, double* euclidian_distance)
{	
	*euclidian_distance=	sqrt(   (d0*d0)+(d1*d1)+(d2*d2)+(d3*d2)    )  ; /*I got the euclidean difference using the formula*/			

    
}


void dhondt_method (int* partyA, int* partyB, int* partyC, int* partyD, int* partyE, int numberOfSeats)
{/*The print process is done on the main.c*/
	int tempA,tempB,tempC,tempD,tempE;
	int max;
	int seatA=0,seatB=0,seatC=0,seatD=0,seatE=0;
	/*I set the number of seats '0' at the beginning. because nobody has any seat at that time*/
	
	tempA=*partyA;/*I have assigned the value to the temporary value to operate.*/
	tempB=*partyB;
	tempC=*partyC;
	tempD=*partyD;
	tempE=*partyE;

	while(numberOfSeats>0){
		max=find_max(tempA,tempB,tempC,tempD,tempE);/*I find the biggest ones*/

			if(max==tempA){/*I increased the number of seats they got if tempA(*partyA) was the largest as a result of the transaction*/
				seatA++;
				tempA=*partyA/(seatA+1);
			}
			else if(max==tempB){
				seatB++;
				tempB=*partyB/(seatB+1);
		
			}
			else if(max==tempC){
				seatC++;
				tempC=*partyC/(seatC+1);
	
			}
			else if(max==tempD){
				seatD++;
				tempD=*partyD/(seatD+1);
			
			}
			else if(max==tempE){
				seatE++;
				tempE=*partyE/(seatE+1);
			
			}
		
			numberOfSeats--;
		
	}

		    *partyA=seatA;
			*partyB=seatB;
			*partyC=seatC;
			*partyD=seatD;
			*partyE=seatE;
}


void order_2d_points_cc (double* x1, double* y1, double* x2, double* y2, double* x3, double* y3)
{/*I ordered according to their distance to the 0,0 point, works the same as find max*/
	double temp1,temp2,temp3,ctrl;
	temp1=(*y1)*(*y1)+(*x1)*(*x1);
	temp2=(*y2)*(*y2)+(*x2)*(*x2);
	temp3=(*y3)*(*y3)+(*x3)*(*x3);

	if((temp1>=temp2 ) &&	(temp1>=temp3)	&& (temp2>=temp3)){/*now I am ordering counter clockwise*/
		;/*no need to order already ordered*/
	}
	else if((temp2>=temp1) && (temp2>=temp3)	&&	(temp1>=temp3)){
		temp1=*x1;
		temp2=*y1;
		*y1=*y2;
		*x1=*x2;
		*y2=temp2;
		*y1=temp1;


	}
	else if((temp3>=temp1) && (temp3>=temp2)  && (temp2>=temp1)){
		temp1=*x1;
		temp2=*y1;
		*y1=*y3;
		*x1=*x3;
		*y3=temp2;
		*x3=temp1;
		temp1=*x1;
		temp2=*y1;
		*y1=*y2;
		*x1=*x2;
		*y2=temp2;
		*y1=temp1;

	}
	else
		;



}


void number_encrypt (unsigned char* number)
{
	char b7='-', b6='-', b5='-', b4='-', b3='-', b2='-', b1='-', b0='-';
	get_number_components (*number, &b7, &b6, &b5, &b4, &b3, &b2, &b1, &b0);

	reconstruct_components (number, b7, b6, b5, b4, b3, b2, b1, b0);
	printf("%d\n",*number);
}


void get_number_components (unsigned char number, char* b7, char* b6, char* b5, char* b4, char* b3, char* b2, char* b1, char* b0)
{
	/*Print is not requested in this section in pdf.*/
	/*The remainder of the division of the number by 2 is taken as bits (msb b7 to lsb b0)*/
	
    int i;
    char temp;
    while(number){
       *b0=number%2;
        number=number/2;
       *b1=number%2;
        number=number/2;
        *b2=number%2;
        number=number/2;
        *b3=number%2;
        number=number/2;
       *b4=number%2;
        number=number/2;
        *b5=number%2;
        number=number/2;
       *b6=number%2;
        number=number/2;
        *b7=number%2;
        number=number/2;
	}
	/*we are not asked to print anything in this function on pdf*/

}


void reconstruct_components (unsigned char* number, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0){
/*Print is not requested in this section in pdf.*/
	char temp;
	int i;
		/*Change bit-7 with bit-2, bit-6 with bit-3, bit-5 with bit-0, bit 4 with bit-1.(temp used for swap operations)*/
		    temp=b7;
		    b7=b2;
		    b2=temp;
		    temp=b6;
		    b6=b3;
		    b3=temp;   
		    temp=b5;
		    b5=b0;
		    b0=temp; 
		    temp=b4;
		    b4=b1;
		    b1=temp;

		 /*Do exactly two circular left shift and obtain: 2 3 0 1 6 7 4 5 --> 0 1 6 7 4 5 2 3(i shifted two bits at once,
		 temp used for shift operation) */ 
		  temp=b0;/*no need the store all the number in temp, only saving some of their first value is working good and enough in my algorithm*/ 
          b0=b6;
          b6=b4;
          b4=b2;
          b2=temp;
          temp=b7;
          b7=b5;
          b5=b3;
          b3=b1;
          b1=temp;

	
	*number=(b7)*pow(2,7) +(b6)*pow(2,6) +(b5)*pow(2,5) +(b4)*pow(2,4) +(b3)*pow(2,3) +(b2)*pow(2,2) +(b1)*pow(2,1) +(b0)*pow(2,0); /*
2^n*(digit) used in binary to decimal transformation b7 is equal to 7. digit and b0 0 equal to 0.digit*/

}



